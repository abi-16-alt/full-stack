// App.js

import { Component } from 'react';
import './App.css';
import Game from './components/Game';

class App extends Component{  
    render(){
      return (
      <Game/>
    );
  }
}

export default App;
