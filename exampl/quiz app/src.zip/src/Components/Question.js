import React from "react";

const Question = ({ question, selectedOption, onOptionChange, onSubmit }) => {
  return (
    <form onSubmit={onSubmit} className="card p-4 shadow">
      <h4>{question.question}</h4>
      {question.options.map((option, index) => (
        <div className="form-check" key={index}>
          <input
            className="form-check-input"
            type="radio"
            name="option"
            value={option}
            id={`option-${index}`}
            checked={selectedOption === option}
            onChange={onOptionChange}
          />
          <label className="form-check-label" htmlFor={`option-${index}`}>
            {option}
          </label>
        </div>
      ))}
      <button type="submit" className="btn btn-primary mt-3">
        Submit
      </button>
    </form>
  );
};

export default Question;
