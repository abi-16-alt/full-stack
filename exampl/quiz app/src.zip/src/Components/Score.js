import React from "react";

const Score = ({ score, total }) => (
  <div className="card p-4 text-center">
    <h2>Quiz Completed!</h2>
    <h3>
      Your Score: {score} / {total}
    </h3>
  </div>
);

export default Score;
