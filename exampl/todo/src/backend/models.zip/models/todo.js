const mongoose = require("mongoose");

const TodoSchema = new mongoose.Schema({
  employeeId: String,
  task: String,
  sequenceNo: Number,
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model("Todo", TodoSchema);
