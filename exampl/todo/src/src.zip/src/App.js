// App.js
import React, { Component } from "react";
import "bootstrap/dist/css/bootstrap.css";
import {
  Container, Row, Col, Button,
  InputGroup, FormControl, ListGroup
} from "react-bootstrap";
import axios from "axios";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      employeeId: "emp001", // <-- You can make this dynamic later
      userInput: "",
      list: [],
    };
  }

  componentDidMount() {
    this.fetchTodos();
  }

  fetchTodos = async () => {
    try {
      const response = await axios.get(
        `http://localhost:5000/api/todos/${this.state.employeeId}`
      );
      this.setState({ list: response.data });
    } catch (err) {
      console.error("Error fetching todos:", err);
    }
  };

  updateInput = (value) => {
    this.setState({ userInput: value });
  };

  addItem = async () => {
    if (this.state.userInput.trim() === "") return;

    try {
      const response = await axios.post("http://localhost:5000/api/todos", {
        employeeId: this.state.employeeId,
        task: this.state.userInput,
      });

      this.setState((prevState) => ({
        list: [...prevState.list, response.data],
        userInput: "",
      }));
    } catch (err) {
      console.error("Error adding todo:", err);
    }
  };

  deleteItem = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/todos/${id}`);
      const updatedList = this.state.list.filter((item) => item._id !== id);
      this.setState({ list: updatedList });
    } catch (err) {
      console.error("Error deleting todo:", err);
    }
  };

  editItem = async (index) => {
    const currentItem = this.state.list[index];
    const editedTask = prompt("Edit the task:", currentItem.task);
    if (!editedTask || editedTask.trim() === "") return;

    try {
      const response = await axios.put(
        `http://localhost:5000/api/todos/${currentItem._id}`,
        { task: editedTask }
      );

      const updatedList = [...this.state.list];
      updatedList[index] = response.data;
      this.setState({ list: updatedList });
    } catch (err) {
      console.error("Error updating todo:", err);
    }
  };

  render() {
    return (
      <Container>
        <Row className="text-center mt-4">
          <h2>TODO LIST (Employee: {this.state.employeeId})</h2>
        </Row>
        <Row className="justify-content-center mt-3">
          <Col md={6}>
            <InputGroup className="mb-3">
              <FormControl
                placeholder="Add task..."
                value={this.state.userInput}
                onChange={(e) => this.updateInput(e.target.value)}
              />
              <Button variant="dark" onClick={this.addItem}>
                ADD
              </Button>
            </InputGroup>
            <ListGroup>
              {this.state.list.map((item, index) => (
                <ListGroup.Item
                  key={item._id}
                  className="d-flex justify-content-between align-items-center"
                >
                  {item.sequenceNo}. {item.task}
                  <span>
                    <Button
                      variant="light"
                      className="me-2"
                      onClick={() => this.editItem(index)}
                    >
                      Edit
                    </Button>
                    <Button
                      variant="danger"
                      onClick={() => this.deleteItem(item._id)}
                    >
                      Delete
                    </Button>
                  </span>
                </ListGroup.Item>
              ))}
            </ListGroup>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default App;
